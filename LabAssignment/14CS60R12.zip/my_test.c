
	read Y;
	aX = (90+7)+6*2+(-34+4);
	while X != 100 do
	{
		print X;
		X = X + 1;
	}

	10;
	20;
	read X;
	x = 10;
	x+5;
	if  x + (5) then
	{	
		10+10;
		x = 20;
	}
	
	else 
	{ 
		z = 6;
	}
	while( 2 ) do
	{
		x = x+4;
	}


