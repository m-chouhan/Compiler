{
	10;
	20;
	
	x = 10;
	{
		x+5;
	}
	if ( x + 15 )
	{	
		10+10;
		x = 20;
	}
	if ( 5) {}
	else 
	{ 
		declare z;
		z = 6;
	}
	while( 2 )
	{
		if(1) {}
		x = x+4;
	}
	1+2+3+4;

}
